# APS – Dados Seguros

Este repositório contém scripts de proteção e visualização segura de dados sensíveis em saúde pública, com foco em Atenção Primária.

## Conteúdo
- anonimizar_dados.sql
- auditar_acessos.sql
- .env.example

Todos os dados são tratados conforme a LGPD.
